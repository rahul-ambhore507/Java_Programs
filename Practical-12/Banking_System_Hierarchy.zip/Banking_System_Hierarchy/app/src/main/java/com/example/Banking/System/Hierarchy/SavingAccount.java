/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Banking.System.Hierarchy;

/**
 *
 * @author rahul
 */
public class SavingAccount extends BankAccount{
    private double minimumBalance;
    private int withdrawalLimit;
    
    public SavingAccount(String accountNumber, String accountHolderName, double balance, String bankName, double minimumBalance, int withdrawalLimit) {
        super(accountNumber, accountHolderName, balance, bankName, "Savings");
        this.minimumBalance = minimumBalance;
        this.withdrawalLimit = withdrawalLimit;
    }
    public void checkWithdrawalLimit() {
        System.out.println("Withdrawal limit: " + withdrawalLimit + " transactions per month.");
    }
}
