/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Banking.System.Hierarchy;

import static com.example.Banking.System.Hierarchy.BankAccount.balance;

/**
 *
 * @author rahul
 */
public class FixedDepositAccount extends BankAccount{
     private String maturityDate;
    private int depositTerm;

    public FixedDepositAccount(String accountNumber, String accountHolderName, double balance, String bankName, String maturityDate, int depositTerm) {
        super(accountNumber, accountHolderName, balance, bankName, "Fixed Deposit");
        this.maturityDate = maturityDate;
        this.depositTerm = depositTerm;
    }

    public double calculateMaturityAmount(double interestRate) {
        double maturityAmount = balance * Math.pow((1 + (interestRate / 100)), depositTerm);
        System.out.println("Maturity amount: " + maturityAmount);
        return maturityAmount;
    }

    public void withdrawBeforeMaturity() {
        System.out.println("Early withdrawal may result in penalties.");
    }
}
