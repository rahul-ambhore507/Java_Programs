/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Banking.System.Hierarchy;

/**
 *
 * @author rahul
 */
public class BankAccount {
    
    static protected String accountNo;
    static protected String accountHolderName;
    static protected String bankName;
    static protected double balance;
    static protected String accountType;
    
    public BankAccount(String accountNo, String accountHolderName, double balance, String bankName, String accountType) {
        this.accountNo = accountNo;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        this.bankName = bankName;
        this.accountType = accountType;
    }
    
    public void deposit(double amount){
        balance +=amount;
        System.out.println(amount+" Amount Deposited , Now Balance : "+balance);
    }
    
    public void getBalance(){
        System.out.println("Current Balance : "+balance);
    }
    
    public void withdraw(double amount){
        if(balance >=amount){
            balance-=amount;
            System.out.println(amount+" Amount withdrawed , Current Balance : "+balance);
        }else{
            System.out.println("Insuffient Balance...");
        }
    }
    
     public void displayAccountInfo() {
        System.out.println("\n--- Account Information ---");
        System.out.println("Account Holder: " + accountHolderName);
        System.out.println("Account Number: " + accountNo);
        System.out.println("Bank Name: " + bankName);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: " + balance);
    }
}
