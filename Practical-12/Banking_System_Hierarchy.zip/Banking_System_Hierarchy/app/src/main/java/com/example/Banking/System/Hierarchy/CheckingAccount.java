/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Banking.System.Hierarchy;

import static com.example.Banking.System.Hierarchy.BankAccount.balance;

/**
 *
 * @author rahul
 */
public class CheckingAccount extends BankAccount{
    private double overdraftLimit;
    private double monthlyFee;
    
public CheckingAccount(String accountNumber, String accountHolderName, int balance, String bankName, int overdraftLimit, int monthlyFee) {
        super(accountNumber, accountHolderName, balance, bankName, "Checking");
        this.overdraftLimit = overdraftLimit;
        this.monthlyFee = monthlyFee;
    }
    
    public void deductMonthlyFee() {
        balance -= monthlyFee;
        System.out.println("Monthly fee deducted. New balance: " + balance);
    }

    public void checkOverdraft() {
        System.out.println("Overdraft limit: " + overdraftLimit);
    }
}
