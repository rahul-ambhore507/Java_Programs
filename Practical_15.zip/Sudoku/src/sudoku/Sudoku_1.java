/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Sudoku;

/**
 *
 * @author Rahul
 */
public class Sudoku_1 {

    /**
     * @param args the command line arguments
     */
    int size = SudokuGUI.gridSize;
    public void setGrid(int size){
        String[][] arr = new String[size][size];
        int count = (int)System.nanoTime()%size+1;
        
        for(int i=0; i<size;i++){
            
            for(int j=0;j<size;j++){
               arr[i][j] = (count%size+1)+"";
               count++;
            }
            count++;
        }
        for(int i=0; i<size;i++){
            for(int j=0;j<size;j++){
                System.out.print(arr[i][j]);
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Sudoku_1 s = new Sudoku_1();
        s.setGrid(3);
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SudokuGUI().setVisible(true);
            }
        });
    }
    
}
